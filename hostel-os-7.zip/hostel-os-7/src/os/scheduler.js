import { wait, signal } from './semaphore'


const ONE_HOUR = 60 * 60 * 1000


// Find resource
const findRes = (s, id) =>
  s.resources.find((r) => r.id === id)


// Find process
const findProc = (s, pid) =>
  s.procs.find((p) => p.pid === pid)



// Create system state
export const newState = (list) => ({
  resources: list.map(
    ([id, name, total, extra = {}]) => ({
      id,
      name,
      total,
      sem: total,
      queue: [],
      ...extra
    })
  ),

  procs: [],

  next: 1,

  msg: '',

  detected: false,

  resolved: false
})



// Get active resources of a student
export function activeResources(s, student) {

  return s.procs.filter(
    (p) =>
      p.student === student &&
      p.state !== 'COMPLETED'
  )
}



// Student requests resource
//
// Supports both:
//
// request(s, student, resourceId)
//
// and
//
// request(s, student, room, resourceId)
export function request(
  s,
  student,
  roomOrId,
  maybeId
) {

  const name = student.trim()

  const room =
    maybeId === undefined
      ? ''
      : roomOrId.trim()

  const id =
    maybeId === undefined
      ? roomOrId
      : maybeId


  if (!name) {

    s.msg =
      'Please enter student name.'

    return false
  }



  // Maximum 2 active requests
  const active =
    activeResources(s, name)


  if (active.length >= 2) {

    s.msg =
      `${name} can use maximum 2 resources at a time.`

    return false
  }



  // Prevent duplicate request
  const duplicate =
    s.procs.find(
      (p) =>
        p.student === name &&
        p.resource === id &&
        p.state !== 'COMPLETED'
    )


  if (duplicate) {

    s.msg =
      `${name} already has a request for this resource.`

    return false
  }



  const p = {

    pid:
      'P' + s.next,

    student:
      name,

    room:
      room || 'Not provided',

    resource:
      id,

    state:
      'READY',

    priority:
      (s.next % 3) + 1,

    holds:
      [],

    startedAt:
      null,

    duration:
      ONE_HOUR
  }


  s.next++


  s.procs.push(p)


  ask(s, p, id)


  return true
}



// Try to allocate resource
export function ask(
  s,
  p,
  id
) {

  const r =
    findRes(s, id)


  if (!r) {

    p.state = 'COMPLETED'

    return false
  }


  p.resource =
    id


  p.state =
    'READY'



  // Resource available
  if (wait(r)) {

    p.state =
      'RUNNING'


    p.holds.push(id)


    p.startedAt =
      Date.now()


    s.msg =
      `${p.pid}: ${r.name} allocated to ${p.student}.`

    return true
  }



  // Resource unavailable
  p.state =
    'WAITING'


  r.queue.push(
    p.pid
  )


  s.msg =
    `${r.name} is busy. ` +
    `${p.student} joined waiting queue ` +
    `at position ${r.queue.length}.`


  return false
}



// Give released resource
// to first FCFS student
function free(
  s,
  id
) {

  const r =
    findRes(s, id)


  if (!r) return



  signal(r)



  const nextPid =
    r.queue.shift()



  if (!nextPid) {

    return
  }



  const nextProcess =
    findProc(
      s,
      nextPid
    )


  if (
    !nextProcess ||
    nextProcess.state !== 'WAITING'
  ) {

    return free(
      s,
      id
    )
  }



  wait(r)


  nextProcess.state =
    'RUNNING'


  nextProcess.holds.push(
    id
  )


  nextProcess.startedAt =
    Date.now()


  s.msg =
    `${r.name} automatically assigned to ` +
    `${nextProcess.student} (${nextProcess.pid}).`
}



// Release process
export function release(
  s,
  pid,
  verb = 'completed'
) {

  const p =
    findProc(
      s,
      pid
    )


  if (!p) return



  // If process was waiting,
  // remove it from queue
  s.resources.forEach(
    (r) => {

      r.queue =
        r.queue.filter(
          (x) => x !== pid
        )

    }
  )



  const held =
    [...p.holds]



  held.forEach(
    (id) => {

      free(
        s,
        id
      )

    }
  )



  p.holds = []

  p.startedAt = null

  p.state =
    'COMPLETED'


  s.msg =
    `${p.student}: ${verb}.`
}



// Automatically release
// resources whose 1-hour timer finished
export function autoReleaseExpired(
  s,
  now = Date.now()
) {

  const expired =
    s.procs.filter(
      (p) =>
        p.state === 'RUNNING' &&
        p.startedAt &&
        now - p.startedAt >= p.duration
    )


  if (
    expired.length === 0
  ) {

    return false
  }



  expired.forEach(
    (p) => {

      release(
        s,
        p.pid,
        '1-hour time limit completed'
      )

    }
  )


  return true
}



// Terminate process
export function terminate(
  s,
  pid
) {

  release(
    s,
    pid,
    'terminated'
  )
}



// Initial HostelSync resources
export function initial() {

  const resources = []


  // ==========================================
  // 40 WASHING MACHINES
  // 10 on each floor
  // ==========================================

  for (
    let floor = 1;
    floor <= 4;
    floor++
  ) {

    for (
      let machine = 1;
      machine <= 10;
      machine++
    ) {

      resources.push({

        id:
          `WM-F${floor}-M${machine}`,

        name:
          `Washing Machine ${machine}`,

        total:
          1,

        sem:
          1,

        queue:
          [],

        category:
          'Washing Machines',

        floor:
          floor,

        machineNumber:
          machine

      })

    }

  }



  // ==========================================
  // DRYERS
  // ==========================================

  resources.push({

    id:
      'DR',

    name:
      'Dryers',

    total:
      25,

    sem:
      25,

    queue:
      [],

    category:
      'Dryers'

  })



  // ==========================================
  // COMMON ROOMS
  // ==========================================

  resources.push({

    id:
      'CR',

    name:
      'Common Rooms',

    total:
      10,

    sem:
      10,

    queue:
      [],

    category:
      'Common Rooms'

  })



  // ==========================================
  // IRON BOXES
  // ==========================================

  resources.push({

    id:
      'IR',

    name:
      'Iron Boxes',

    total:
      25,

    sem:
      25,

    queue:
      [],

    category:
      'Iron Boxes'

  })



  return {

    resources,

    procs: [],

    next: 1,

    msg: '',

    detected: false,

    resolved: false

  }
}