import { newState, request, ask } from './scheduler'

// Find a deadlock cycle using DFS
export function findCycle(procs) {

  const graph = {}

  // Create a node for every process
  procs.forEach((p) => {
    graph[p.pid] = []
  })

  // Create edges:
  // WAITING process → process holding its requested resource
  procs
    .filter((p) => p.state === 'WAITING')
    .forEach((p) => {

      procs.forEach((q) => {

        if (
          q.pid !== p.pid &&
          q.holds.includes(p.resource)
        ) {
          graph[p.pid].push(q.pid)
        }

      })

    })


  const seen = new Set()

  // DFS
  const dfs = (node, path) => {

    // Cycle found
    if (path.includes(node)) {
      return [
        ...path.slice(path.indexOf(node)),
        node
      ]
    }

    if (seen.has(node)) {
      return null
    }

    seen.add(node)

    for (const next of graph[node]) {

      const cycle = dfs(
        next,
        [...path, node]
      )

      if (cycle) {
        return cycle
      }

    }

    return null
  }


  // Check every process
  for (const p of procs) {

    const cycle = dfs(
      p.pid,
      []
    )

    if (cycle) {
      return cycle
    }

  }

  return null
}


// Create a sample deadlock
export function scenario() {

  const s = newState([
    ['WM', 'Washing Machine', 1],
    ['DR', 'Dryer', 1],
    ['IR', 'Iron', 1]
  ])


  // P1 gets Washing Machine
  // P2 gets Dryer
  // P3 gets Iron
  ;[
    ['Rahul', 'WM'],
    ['Priya', 'DR'],
    ['Anu', 'IR']
  ].forEach(([name, id]) => {
    request(s, name, id)
  })


  const [p1, p2, p3] = s.procs


  // P1 waits for Dryer
  ask(s, p1, 'DR')

  // P2 waits for Iron
  ask(s, p2, 'IR')

  // P3 waits for Washing Machine
  ask(s, p3, 'WM')


  s.msg =
    'Deadlock scenario created: P1 → Dryer, P2 → Iron, P3 → Washing Machine'

  return s
}