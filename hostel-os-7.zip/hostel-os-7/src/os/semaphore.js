// Counting semaphore

export function wait(resource) {

  if (resource.sem > 0) {

    resource.sem--

    return true

  }

  return false

}


export function signal(resource) {

  resource.sem++

}