import { useEffect, useMemo, useState } from 'react'
import './App.css'

const DURATIONS = { washer: 60 * 60 * 1000, dryer: 30 * 60 * 1000, iron: 30 * 60 * 1000, seat: 2 * 60 * 60 * 1000 }
const LABELS = { washer: 'Washing machine', dryer: 'Dryer', iron: 'Iron box', seat: 'Common room seat' }
const ICONS = { washer: '🧺', dryer: '🌬️', iron: '🔌', seat: '🛋️' }
const localDate = (date = new Date()) => { const d = new Date(date.getTime() - date.getTimezoneOffset() * 60000); return d.toISOString().slice(0, 10) }
const TIME_SLOTS = Array.from({ length: 32 }, (_, i) => { const minutes = 6 * 60 + i * 30; return `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}` })
const slotsForType = type => TIME_SLOTS.filter((time, index) => type !== 'washer' || Number(time.slice(3)) === 0)
const prettyDateTime = value => new Date(value).toLocaleString([], { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' })
const SEED = () => {
  const resources = []
  for (let floor = 1; floor <= 3; floor++) {
    for (let n = 1; n <= 4; n++) resources.push({ id: `F${floor}-WM${n}`, type: 'washer', floor, label: `WM ${n}`, owner: null, startedAt: null, endsAt: null, queue: [], bookings: [] })
    for (let n = 1; n <= 2; n++) resources.push({ id: `F${floor}-DR${n}`, type: 'dryer', floor, label: `Dryer ${n}`, owner: null, startedAt: null, endsAt: null, queue: [], bookings: [] })
    for (let n = 1; n <= 2; n++) resources.push({ id: `F${floor}-IR${n}`, type: 'iron', floor, label: `Iron ${n}`, owner: null, startedAt: null, endsAt: null, queue: [], bookings: [] })
  }
  for (let n = 1; n <= 50; n++) resources.push({ id: `CR-${String(n).padStart(2, '0')}`, type: 'seat', floor: 0, label: `Seat ${n}`, owner: null, startedAt: null, endsAt: null, queue: [], bookings: [] })
  return resources
}
const readSaved = () => {
  try {
    const value = JSON.parse(localStorage.getItem('hostelsync-state-v2'))
    if (value?.resources?.length === 74) return value
  } catch {}
  return { resources: SEED(), events: [], nextEvent: 1 }
}
const timeLeft = (endsAt, now) => Math.max(0, Math.ceil(((endsAt || now) - now) / 1000))
const fmt = (seconds) => `${String(Math.floor(seconds / 3600)).padStart(2, '0')}:${String(Math.floor(seconds % 3600 / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`
const durationLabel = (type) => type === 'washer' ? '1 hour' : type === 'seat' ? '2 hours' : '30 min'

export default function App() {
  const [system, setSystem] = useState(readSaved)
  const [now, setNow] = useState(Date.now())
  const [user, setUser] = useState(() => {
    try { return JSON.parse(sessionStorage.getItem('hostelsync-user')) } catch { return null }
  })
  const [loginName, setLoginName] = useState('')
  const [room, setRoom] = useState('')
  const [tab, setTab] = useState('Overview')
  const [floor, setFloor] = useState(1)
  const [filter, setFilter] = useState('all')
  const [selectedType, setSelectedType] = useState('washer')
  const [notice, setNotice] = useState(null)
  const [expiry, setExpiry] = useState(null)
  const [conflict, setConflict] = useState(null)
  const [deadlockDemo, setDeadlockDemo] = useState(false)
  const [deadlockResult, setDeadlockResult] = useState(null)
  const [browserNotifications, setBrowserNotifications] = useState(false)
  const [bookingSlots, setBookingSlots] = useState({})
  const slotFor = id => bookingSlots[id] || { date: localDate(), time: '17:00' }
  const changeSlot = (id, field, value) => setBookingSlots(old => ({ ...old, [id]: { ...slotFor(id), [field]: value } }))

  useEffect(() => { localStorage.setItem('hostelsync-state-v2', JSON.stringify(system)); fetch('/api/state', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(system) }).catch(() => {}) }, [system])
  useEffect(() => { let alive = true; const pull = async () => { try { const res = await fetch('/api/state'); if (!res.ok) return; const saved = await res.json(); if (alive && saved?.resources?.length === 74) setSystem(current => JSON.stringify(current) === JSON.stringify(saved) ? current : saved) } catch {} }; pull(); const id = setInterval(pull, 1200); return () => { alive = false; clearInterval(id) } }, [])
  useEffect(() => { const id = setInterval(() => setNow(Date.now()), 1000); return () => clearInterval(id) }, [])
  useEffect(() => { if (user) sessionStorage.setItem('hostelsync-user', JSON.stringify(user)); else sessionStorage.removeItem('hostelsync-user') }, [user])
  useEffect(() => {
    const due = system.resources.filter(r => r.owner && r.owner.name === user?.name && r.endsAt && r.endsAt <= now && !r.expiryNotified)
    if (due.length) {
      setSystem(old => ({ ...old, resources: old.resources.map(r => due.some(d => d.id === r.id) ? { ...r, expiryNotified: true } : r) }))
      const first = due[0]
      setExpiry({ resourceId: first.id, owner: first.owner, label: first.label, type: first.type, count: due.length })
      notify(`Time is up for ${first.label}`, `${first.owner.name}, your allocated time has ended. Extend or release the resource.`)
    }
  }, [now, system.resources])
  useEffect(() => {
    const sync = () => { try { const saved = JSON.parse(localStorage.getItem('hostelsync-state-v2')); if (saved?.resources?.length === 74) setSystem(saved) } catch {} }
    window.addEventListener('storage', sync)
    return () => window.removeEventListener('storage', sync)
  }, [])
  const notify = (title, body) => {
    setNotice({ title, body, id: Date.now() })
    if (browserNotifications && 'Notification' in window && Notification.permission === 'granted') new Notification(title, { body })
  }
  const updateResource = (id, updater) => setSystem(old => ({ ...old, resources: old.resources.map(r => r.id === id ? updater(r) : r) }))
  const activeMine = useMemo(() => user ? system.resources.filter(r => r.owner?.name === user.name) : [], [system.resources, user])
  const counts = useMemo(() => {
    const all = system.resources.filter(r => r.type !== 'seat')
    const occupied = all.filter(r => r.owner).length
    const seats = system.resources.filter(r => r.type === 'seat')
    return { total: all.length, occupied, available: all.length - occupied, seatsUsed: seats.filter(r => r.owner).length, seatsFree: seats.filter(r => !r.owner).length, waiting: all.reduce((n, r) => n + r.queue.length, 0) }
  }, [system.resources])
  const login = e => {
    e.preventDefault()
    if (!loginName.trim() || !room.trim()) return
    setUser({ name: loginName.trim(), room: room.trim() })
    setTab('Overview')
  }
  const allocate = resource => {
    if (!user) return
    if (resource.owner) {
      if (resource.owner.name === user.name) {
        notify('Already yours 💛', `You are already using ${resource.label}. You can manage it under My bookings.`)
        return
      }
      setConflict({ id: resource.id, owner: resource.owner, label: resource.label, type: resource.type })
      return
    }
    const currentCount = system.resources.filter(r => r.owner?.name === user.name).length
    if (currentCount >= 2) {
      notify('Just 2 resources at a time 🌷', `You already have ${currentCount} resources booked. Please release one before booking another.`)
      return
    }
    if (resource.queue?.length) {
      notify('Queue in progress', 'This resource has a waiting list. Please join the queue to preserve first-come, first-served order.')
      return
    }
    const start = Date.now()
    updateResource(resource.id, r => ({ ...r, owner: user, startedAt: start, endsAt: start + DURATIONS[r.type], expiryNotified: false }))
    notify('Resource allocated', `${resource.label} is reserved for ${user.name} for ${durationLabel(resource.type)}.`)
  }
  const scheduleResource = resource => {
    if (!user) return
    const slot = slotFor(resource.id)
    const start = new Date(`${slot.date}T${slot.time}:00`).getTime()
    const end = start + DURATIONS[resource.type]
    if (!Number.isFinite(start) || start <= Date.now()) { notify('Pick a future time 🌷', 'Choose a date and time that has not passed yet.'); return }
    const reservations = system.resources.flatMap(r => (r.bookings || []).filter(b => b.owner?.name === user.name && start < b.endAt && end > b.startAt))
    const active = system.resources.filter(r => r.owner?.name === user.name && start < (r.endsAt || 0) && end > (r.startedAt || 0)).length
    if (reservations.length + active >= 2) { notify('Only 2 resources at a time 🧸', 'You already have two resources booked during this time. Choose a different slot or cancel one overlapping booking.'); return }
    const collision = (resource.bookings || []).find(b => start < b.endAt && end > b.startAt)
    const liveCollision = resource.owner && start < (resource.endsAt || Infinity) && end > (resource.startedAt || 0)
    if (collision || liveCollision) {
      const bookedBy = collision?.owner || resource.owner
      notify('That time slot is taken 💗', `${bookedBy?.name || 'Another student'} has ${resource.label} booked for ${prettyDateTime(collision?.startAt || resource.startedAt)}. Please choose another slot or resource.`)
      return
    }
    const booking = { id: `${resource.id}-${start}-${user.name}`, owner: user, startAt: start, endAt: end }
    updateResource(resource.id, r => ({ ...r, bookings: [...(r.bookings || []), booking].sort((a,b) => a.startAt-b.startAt) }))
    notify('Cute little plan saved ✨', `${resource.label} is booked for ${prettyDateTime(start)}–${new Date(end).toLocaleTimeString([], {hour:'numeric', minute:'2-digit'})}.`)
  }
  const cancelScheduled = (resourceId, bookingId) => {
    const resource = system.resources.find(r => r.id === resourceId)
    const booking = resource?.bookings?.find(b => b.id === bookingId)
    if (!booking || booking.owner?.name !== user?.name) return
    updateResource(resourceId, r => ({ ...r, bookings: (r.bookings || []).filter(b => b.id !== bookingId) }))
    notify('Booking cancelled 🌼', `${resource.label} is available for that time slot again.`)
  }
  const queueResource = id => {
    const r = system.resources.find(x => x.id === id)
    if (!r || !user) return
    if (r.queue.some(q => q.name === user.name) || r.owner?.name === user.name) { notify('Already requested', 'You already use or wait for this resource.'); return }
    updateResource(id, x => ({ ...x, queue: [...x.queue, { ...user, requestedAt: Date.now() }] }))
    notify('Added to waiting queue', `${user.name}, you are #${r.queue.length + 1} in line for ${r.label}.`)
    setConflict(null)
  }
  const releaseResource = (id, byUser = user) => {
    const r = system.resources.find(x => x.id === id)
    if (!r) return
    const nextInLine = r.queue[0]
    updateResource(id, x => nextInLine ? ({ ...x, owner: { name: nextInLine.name, room: nextInLine.room }, startedAt: Date.now(), endsAt: Date.now() + DURATIONS[x.type], expiryNotified: false, queue: x.queue.slice(1) }) : ({ ...x, owner: null, startedAt: null, endsAt: null, expiryNotified: false }))
    setExpiry(null)
    notify('Resource released', nextInLine ? `${r.label} has been allocated to ${nextInLine.name} from the waiting queue.` : `${r.label} is now available.`)
  }
  const extendResource = id => {
    const r = system.resources.find(x => x.id === id)
    if (!r || r.owner?.name !== user?.name) { notify('Cannot extend', 'Only the current user can extend this booking.'); setExpiry(null); return }
    updateResource(id, x => ({ ...x, endsAt: Math.max(Date.now(), x.endsAt || 0) + DURATIONS[x.type], expiryNotified: false }))
    setExpiry(null)
    notify('Booking extended', `${r.label} has been extended by ${durationLabel(r.type)}.`)
  }
  const toggleNotifications = async () => {
    if (!('Notification' in window)) { notify('Browser notifications unavailable', 'In-app notifications will still work in this browser.'); return }
    const permission = await Notification.requestPermission()
    setBrowserNotifications(permission === 'granted')
    notify(permission === 'granted' ? 'Notifications enabled' : 'Notifications not enabled', permission === 'granted' ? 'You can receive browser notifications while this site is open.' : 'Allow notifications in your browser settings to enable them.')
  }
  const openDeadlockDemo = () => {
    setDeadlockDemo(true)
    setDeadlockResult(null)
  }
  const detectDeadlock = () => setDeadlockResult({ cycle: ['Keerthi', 'Washing Machine 1', 'Siri', 'Dryer 1', 'Keerthi'], explanation: 'A circular wait exists in this demonstration scenario. Each student holds one resource and waits for a resource held by the other student.' })
  const resolveDeadlock = () => { setDeadlockResult({ resolved: true, explanation: 'Recovery simulated: the system selects Siri’s waiting request for cancellation and releases the held resource. In the live resource center, release or cancel a request to free resources.' }); setDeadlockDemo(false) }
  const visibleResources = system.resources.filter(r => r.floor === floor && (selectedType === 'seat' ? r.type === 'seat' : r.type === selectedType))
  const renderResource = r => {
    const mine = r.owner?.name === user?.name
    const left = r.owner ? timeLeft(r.endsAt, now) : 0
    return <article className={`resource-card ${r.owner ? 'occupied' : 'available'}`} key={r.id}>
      <div className="resource-card-top"><span className="resource-icon">{ICONS[r.type]}</span><span className={`status ${r.owner ? 'busy' : 'free'}`}>{r.owner ? 'In use' : 'Available'}</span></div>
      <h3>{r.label}</h3><p className="muted">{LABELS[r.type]} · Floor {r.floor}</p><span className="duration-badge">⏳ Booking length: {durationLabel(r.type)}</span>
      {r.owner ? <div className="owner-block"><span className="owner-avatar">{r.owner.name.slice(0,1).toUpperCase()}</span><div><strong>{r.owner.name}</strong><small>Room {r.owner.room || '—'}</small></div></div> : <div className="available-note">Ready for your booking</div>}
      {r.owner && <div className="timer-wrap"><div className="timer-label"><span>{left === 0 ? 'Time ended' : 'Time remaining'}</span><strong>{fmt(left)}</strong></div><div className="progress-track"><div className="progress-fill" style={{ width: `${Math.min(100, left / (DURATIONS[r.type] / 1000) * 100)}%` }}/></div></div>}
      <div className="slot-booker"><div className="slot-heading">🗓️ Plan a time slot <small>This resource is booked independently for {durationLabel(r.type)}.</small></div><label>Date<input type="date" min={localDate()} value={slotFor(r.id).date} onChange={e=>changeSlot(r.id,'date',e.target.value)}/></label><label>Start time<select value={slotFor(r.id).time} onChange={e=>changeSlot(r.id,'time',e.target.value)}>{slotsForType(r.type).filter(t => Number(t.slice(0, 2)) < 22).map(t=><option key={t} value={t}>{new Date(`2000-01-01T${t}:00`).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})} – {new Date(new Date(`2000-01-01T${t}:00`).getTime() + DURATIONS[r.type]).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}</option>)}</select></label><button className="button button-soft full" onClick={()=>scheduleResource(r)}>Book this slot ✨</button></div>
      {(r.bookings || []).filter(b=>b.endAt>Date.now()).sort((a,b)=>a.startAt-b.startAt).slice(0,3).map(b=><div className="scheduled-chip" key={b.id}><span>📅</span><div><strong>{prettyDateTime(b.startAt)}</strong><small>Reserved by {b.owner.name}</small></div>{b.owner.name===user?.name && <button title="Cancel booking" onClick={()=>cancelScheduled(r.id,b.id)}>×</button>}</div>)}
      {r.queue.length > 0 && <div className="queue-note"><span>◷</span> {r.queue.length} waiting · {r.queue.map(q => q.name).join(', ')}</div>}
      {mine ? <button className="button button-danger full" onClick={() => releaseResource(r.id)}>Release resource</button> : r.owner ? <button className="button button-secondary full" onClick={() => setConflict({ id: r.id, owner: r.owner, label: r.label, type: r.type })}>Request this resource</button> : <button className="button button-primary full" onClick={() => allocate(r)}>Reserve for {durationLabel(r.type)}</button>}
    </article>
  }
  if (!user) return <div className="login-screen cute-login"><div className="login-side"><div className="brand brand-light"><span className="brand-mark">🌷</span><span>Hostel<span className="brand-accent">Sync</span><small>YOUR HOSTEL, IN HARMONY</small></span></div><div className="login-copy"><span className="eyebrow">A LITTLE MORE ORGANIZED ✨</span><h1>Your cozy corner<br/>of hostel life.</h1><p>Book laundry time, find your spot, and keep shared spaces happy — all in one cute little place.</p><div className="login-highlights"><span>🧺 Laundry slots made easy</span><span>🧸 Shared spaces, less stress</span><span>🌼 Fair turns for everyone</span></div><div className="login-stickers"><span>🫧</span><span>🌸</span><span>🧺</span><span>☁️</span></div></div><div className="login-footer">MADE FOR HOSTEL DAYS & LITTLE WINS 💗</div></div><div className="login-main"><form className="login-card cute-login-card" onSubmit={login}><div className="login-symbol">💌</div><span className="eyebrow">STUDENT CORNER</span><h2>Hey there, sunshine!</h2><p className="muted">Pop in your details and let's get you settled.</p><label>Your name<input value={loginName} onChange={e => setLoginName(e.target.value)} placeholder="e.g. Keerthi Reddy" required/></label><label>Room number<input value={room} onChange={e => setRoom(e.target.value)} placeholder="e.g. B-204" required/></label><button className="button button-primary full" type="submit">Let's go in 🌷 <span>→</span></button><small className="login-note">Demo access · No password required</small><div className="login-card-note">💗 Be kind, take turns, leave it lovely.</div></form></div></div>

  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><span className="brand-mark">H</span><span>Hostel<span className="brand-accent">Sync</span><small>RESOURCE OS</small></span></div><div className="side-label">WORKSPACE</div><nav className="side-nav">
      {[['Overview','▦'],['Resource center','▤'],['My bookings','◷'],['Waiting queue','☷'],['Deadlock lab','⟳'],['Processes & OS','⌘']].map(([name, icon]) => <button key={name} className={tab === name ? 'selected' : ''} onClick={() => setTab(name)}><span className="nav-icon">{icon}</span>{name}{name === 'Deadlock lab' && <span className="nav-tag">OS</span>}</button>)}
    </nav><div className="sidebar-bottom"><div className="system-health"><span className="health-dot"/>System operational<strong>Resource manager active</strong></div><div className="profile-row"><span className="profile-avatar">{user.name.slice(0,1).toUpperCase()}</span><div className="profile-copy"><strong>{user.name}</strong><small>Room {user.room}</small></div><button className="icon-button" title="Switch student" onClick={() => setUser(null)}>⇄</button></div></div></aside>
    <main className="main-panel"><header className="topbar"><div className="breadcrumbs">HostelSync <span>/</span> <strong>{tab}</strong></div><div className="top-actions"><span className="today-pill"><span className="health-dot"/> Live system</span><button className="notification-button" onClick={toggleNotifications} title="Enable browser notifications">♧<i/></button><div className="top-user"><span className="profile-avatar small">{user.name.slice(0,1).toUpperCase()}</span><strong>{user.name}</strong></div></div></header>
      {notice && <div className="toast" key={notice.id}><span className="toast-check">✓</span><div><strong>{notice.title}</strong><p>{notice.body}</p></div><button onClick={() => setNotice(null)}>×</button></div>}
      <div className="page-content">
      {tab === 'Overview' && <><section className="welcome-banner"><div><span className="eyebrow">HOSTEL OPERATIONS / OVERVIEW</span><h1>Good to see you, {user.name.split(' ')[0]} <span>✦</span></h1><p>Everything you need for your shared spaces, in one place.</p><div className="banner-actions"><button className="button button-light" onClick={() => setTab('Resource center')}>Explore resources <span>→</span></button><button className="button button-ghost" onClick={() => setTab('Deadlock lab')}>Explore OS lab</button></div></div><div className="banner-art"><div className="art-circle circle-one"/><div className="art-circle circle-two"/><div className="art-card"><span>LIVE RESOURCE STATUS</span><div className="art-number">{counts.available}<small> available</small></div><div className="art-mini-bars"><i/><i/><i/><i/><i/><i/><i/></div><small>Across 3 floors</small></div><div className="art-floating">✦</div></div></section>
        <div className="section-heading"><div><h2>Resource snapshot</h2><p>Current hostel-wide availability</p></div><button className="text-button" onClick={() => setTab('Resource center')}>View all resources →</button></div>
        <div className="stat-grid"><div className="stat-card"><span className="stat-icon lilac">▤</span><span className="stat-label">Total equipment</span><strong>{counts.total}</strong><small>12 washers · 6 dryers · 6 irons</small></div><div className="stat-card"><span className="stat-icon green">✓</span><span className="stat-label">Available now</span><strong>{counts.available}</strong><small>{counts.occupied} currently in use</small></div><div className="stat-card"><span className="stat-icon amber">◷</span><span className="stat-label">Waiting requests</span><strong>{counts.waiting}</strong><small>First-come, first-served queues</small></div><div className="stat-card"><span className="stat-icon blue">▦</span><span className="stat-label">Common room seats</span><strong>{counts.seatsFree}<small className="stat-denom"> / 50</small></strong><small>{counts.seatsUsed} seats currently occupied</small></div></div>
        <div className="overview-grid"><section className="panel floors-panel"><div className="section-heading compact"><div><h2>Browse by floor</h2><p>24 facilities across 3 floors</p></div><button className="text-button" onClick={() => setTab('Resource center')}>Open center →</button></div><div className="floor-overview">{[1,2,3].map(f => {const rs=system.resources.filter(r=>r.floor===f);const busy=rs.filter(r=>r.owner).length;return <button className="floor-row" key={f} onClick={()=>{setFloor(f);setTab('Resource center')}}><span className="floor-icon">⌂</span><span className="floor-info"><strong>Floor {f}</strong><small>4 washers · 2 dryers · 2 irons</small></span><span className="floor-meter"><span><i style={{width:`${busy/rs.length*100}%`}}/></span><small>{rs.length-busy} of {rs.length} free</small></span><span className="row-arrow">→</span></button>})}</div></section><section className="panel personal-panel"><div className="section-heading compact"><div><h2>Your active bookings</h2><p>Reservations assigned to you</p></div><span className="count-chip">{activeMine.length}</span></div>{activeMine.length ? <div className="personal-list">{activeMine.map(r=><div className="personal-item" key={r.id}><span className="resource-icon small-icon">{ICONS[r.type]}</span><div><strong>{r.label}</strong><small>{LABELS[r.type]} · {r.floor ? `Floor ${r.floor}` : 'Common room'}</small></div><strong className="personal-time">{fmt(timeLeft(r.endsAt,now))}</strong></div>)}</div>:<div className="empty-state"><span>◷</span><strong>No active bookings</strong><p>Reserve a resource to see your timer here.</p><button className="text-button" onClick={()=>setTab('Resource center')}>Find a resource →</button></div>}</section></div>
        <section className="panel common-room-banner"><div className="common-icon">🛋️</div><div className="common-copy"><span className="eyebrow">SHARED LOUNGE</span><h2>Common room</h2><p>Reserve one of 50 seats for up to two hours.</p><div className="seat-track"><span style={{width:`${counts.seatsUsed/50*100}%`}}/></div><small>{counts.seatsFree} seats available · {counts.seatsUsed} occupied</small></div><button className="button button-primary" onClick={()=>setTab('Resource center')}>Book a seat →</button></section>
      </>}
      {tab === 'Resource center' && <><div className="page-title"><div><span className="eyebrow">RESERVATIONS</span><h1>Resource center</h1><p>First choose what you want to use, then choose a floor and an available resource. Common room is on the ground floor only.</p></div><div className="legend"><span><i className="dot green-dot"/> Available</span><span><i className="dot red-dot"/> In use</span></div></div><section className="resource-choice-panel"><h2>1. What would you like to use?</h2><p>Choose one option to see the matching resources.</p><div className="resource-choice-grid">{[{id:'washer',icon:'🧺',title:'Washing machine',sub:'1 hour'},{id:'dryer',icon:'🌬️',title:'Dryer',sub:'30 minutes'},{id:'iron',icon:'🔌',title:'Iron box',sub:'30 minutes'},{id:'seat',icon:'🛋️',title:'Common room',sub:'Ground floor · 2 hours'}].map(x=><button key={x.id} className={`resource-choice ${selectedType===x.id?'active':''}`} onClick={()=>{setSelectedType(x.id);setFloor(x.id==='seat'?0:Math.max(1,floor));setFilter(x.id)}}><span>{x.icon}</span><strong>{x.title}</strong><small>{x.sub}</small></button>)}</div></section><div className="resource-toolbar"><div><h3>2. Choose a floor</h3><div className="floor-tabs">{(selectedType==='seat'?[0]:[1,2,3]).map(f=><button key={f} className={floor===f?'active':''} onClick={()=>setFloor(f)}>{f===0?'Ground Floor':`Floor ${f}`}</button>)}</div></div></div><div className="resource-summary"><span><strong>{visibleResources.filter(r=>!r.owner).length}</strong> available</span><span><strong>{visibleResources.filter(r=>r.owner).length}</strong> in use</span><span>Choose a resource below to book your own slot.</span></div>{selectedType==='seat'?<section className="panel seats-panel"><div className="section-heading"><div><h2>Common room · 50 seats</h2><p>Ground floor only · Choose a seat for up to two hours</p></div><span className="count-chip">{counts.seatsFree} available</span></div><div className="seat-grid">{visibleResources.map(r=><button key={r.id} className={`seat-tile ${r.owner?'seat-busy':''} ${r.owner?.name===user.name?'seat-mine':''}`} title={r.owner?`${r.label}: ${r.owner.name}`:`${r.label} available`} onClick={()=>allocate(r)}>{r.owner?.name===user.name?'✓':r.owner?'•':r.label.replace('Seat ','')}</button>)}</div><div className="seat-legend"><span><i className="dot green-dot"/> Available</span><span><i className="dot red-dot"/> Occupied</span><span><i className="dot blue-dot"/> Yours</span></div></section>:<><h3 className="resource-step-title">3. Choose your {selectedType==='washer'?'washing machine':selectedType==='dryer'?'dryer':'iron box'}</h3><div className="resource-grid">{visibleResources.map(renderResource)}</div></>}</>}
      {tab === 'My bookings' && <><div className="page-title"><div><span className="eyebrow">YOUR ACTIVITY</span><h1>My bookings</h1><p>Manage your active reservations and remaining time. You can hold up to 2 resources at once ({activeMine.length}/2 in use).</p></div></div>{activeMine.length ? <div className="resource-grid">{activeMine.map(renderResource)}</div> : <div className="panel empty-large"><span>◷</span><h2>Nothing booked yet</h2><p>Browse available facilities to make your first reservation.</p><button className="button button-primary" onClick={()=>setTab('Resource center')}>Explore resources →</button></div>}</>}
      {tab === 'My bookings' && <section className="panel scheduled-panel"><div className="section-heading"><div><h2>📅 My upcoming slots</h2><p>Your future plans, all in one place.</p></div></div>{system.resources.flatMap(r=>(r.bookings||[]).filter(b=>b.owner?.name===user.name && b.endAt>Date.now()).map(b=>({...b,resource:r}))).sort((a,b)=>a.startAt-b.startAt).length ? <div className="upcoming-list">{system.resources.flatMap(r=>(r.bookings||[]).filter(b=>b.owner?.name===user.name && b.endAt>Date.now()).map(b=>({...b,resource:r}))).sort((a,b)=>a.startAt-b.startAt).map(b=><div className="upcoming-row" key={b.id}><span className="upcoming-emoji">{ICONS[b.resource.type]}</span><div><strong>{b.resource.label} · {LABELS[b.resource.type]}</strong><small>{prettyDateTime(b.startAt)} – {new Date(b.endAt).toLocaleTimeString([], {hour:'numeric',minute:'2-digit'})}</small><small>Floor {b.resource.floor || 'Common room'}</small></div><button className="button button-secondary small-button" onClick={()=>cancelScheduled(b.resource.id,b.id)}>Cancel</button></div>)}</div> : <div className="empty-state"><strong>No upcoming slots just yet 🌸</strong><p>Head to Resource center and choose a date and time to plan ahead.</p></div>}</section>}
      {tab === 'Waiting queue' && <><div className="page-title"><div><span className="eyebrow">FIRST COME, FIRST SERVED</span><h1>Waiting queue</h1><p>Live queues for busy resources. Releasing a resource allocates it to the next student.</p></div></div><div className="panel table-panel"><div className="table-scroll"><table><thead><tr><th>Resource</th><th>Floor</th><th>Currently using</th><th>Waiting students</th><th>Position</th><th>Action</th></tr></thead><tbody>{system.resources.filter(r=>r.type!=='seat' && (r.owner || r.queue.length)).map(r=><tr key={r.id}><td><strong>{ICONS[r.type]} {r.label}</strong><small>{LABELS[r.type]}</small></td><td>{r.floor}</td><td>{r.owner?.name || '—'}</td><td>{r.queue.map(q=>q.name).join(', ') || 'No one waiting'}</td><td>{r.queue.findIndex(q=>q.name===user.name) >= 0 ? `#${r.queue.findIndex(q=>q.name===user.name)+1}` : '—'}</td><td>{r.owner && r.owner.name!==user.name ? <button className="button button-secondary small-button" onClick={()=>queueResource(r.id)}>Join queue</button> : r.owner?.name===user.name ? <button className="button button-danger small-button" onClick={()=>releaseResource(r.id)}>Release</button> : '—'}</td></tr>)}</tbody></table></div>{!system.resources.some(r=>r.type!=='seat'&&(r.owner||r.queue.length))&&<div className="empty-state"><strong>No active queues</strong><p>When a resource is busy, students can join its queue.</p></div>}</div></>}
      {tab === 'Deadlock lab' && <><div className="page-title"><div><span className="eyebrow">OPERATING SYSTEMS SIMULATOR</span><h1>Deadlock detection lab</h1><p>Explore circular wait, resource allocation graphs, and recovery strategies.</p></div><span className="lab-pill">OS CONCEPT</span></div><div className="deadlock-grid"><section className="panel deadlock-intro"><span className="stat-icon red">⟳</span><h2>What is a deadlock?</h2><p>A deadlock occurs when processes wait indefinitely for resources held by each other. HostelSync demonstrates the four classic conditions: mutual exclusion, hold and wait, no preemption, and circular wait.</p><div className="deadlock-actions"><button className="button button-primary" onClick={openDeadlockDemo}>Load deadlock scenario</button><button className="button button-secondary" onClick={()=>{setDeadlockDemo(false);setDeadlockResult(null)}}>Reset lab</button></div><div className="condition-list">{['Mutual exclusion','Hold and wait','No preemption','Circular wait'].map((c,i)=><div key={c}><span>{String(i+1).padStart(2,'0')}</span>{c}<b>✓</b></div>)}</div></section><section className="panel graph-panel"><div className="section-heading compact"><div><h2>Resource allocation graph</h2><p>Process → requested resource → owner</p></div><span className={`status ${deadlockResult?.cycle?'busy':'free'}`}>{deadlockResult?.cycle?'Cycle found':'Ready to simulate'}</span></div>{deadlockDemo ? <div className="graph-demo"><div className="graph-node process-node">P1 · Keerthi<small>Holds Washer 1</small></div><div className="graph-arrow">↓ requests</div><div className="graph-node resource-node">Washer 1<small>Held by Siri</small></div><div className="graph-arrow">↓ allocated to</div><div className="graph-node process-node">P2 · Siri<small>Holds Dryer 1</small></div><div className="graph-arrow">↓ requests</div><div className="graph-node resource-node">Dryer 1<small>Held by Keerthi</small></div><div className="graph-arrow">↺ circular wait</div></div> : <div className="graph-placeholder"><span>⟳</span><strong>No scenario loaded</strong><p>Load a sample to visualize a circular wait between two processes.</p></div>}{deadlockResult?.cycle && <div className="deadlock-alert"><strong>⚠ Deadlock detected</strong><p>{deadlockResult.cycle.join(' → ')}</p><small>{deadlockResult.explanation}</small></div>}{deadlockResult?.resolved && <div className="success-alert"><strong>✓ Recovery simulated</strong><p>{deadlockResult.explanation}</p></div>}<div className="graph-actions"><button className="button button-primary" disabled={!deadlockDemo} onClick={detectDeadlock}>Detect deadlock</button><button className="button button-danger" disabled={!deadlockResult?.cycle} onClick={resolveDeadlock}>Resolve deadlock</button></div></section></div><section className="panel live-os-panel"><div className="section-heading compact"><div><h2>Live resource status</h2><p>Real resource occupancy from this session</p></div><span className="count-chip">{counts.waiting} waiting</span></div><div className="os-mini-grid"><div><span>Active allocations</span><strong>{counts.occupied + counts.seatsUsed}</strong></div><div><span>Available facilities</span><strong>{counts.available + counts.seatsFree}</strong></div><div><span>Waiting processes</span><strong>{system.resources.reduce((n,r)=>n+r.queue.length,0)}</strong></div><div><span>Resource types</span><strong>4</strong></div></div><p className="muted tiny">Note: the deadlock scenario is a controlled teaching simulation. Live bookings are managed separately; the graph demonstrates how circular waits form and how recovery can be performed.</p></section></>}
      {tab === 'Processes & OS' && <><div className="page-title"><div><span className="eyebrow">SYSTEM MONITOR</span><h1>Processes & OS</h1><p>Every reservation is represented as a process and every facility as a managed resource.</p></div></div><div className="stat-grid"><div className="stat-card"><span className="stat-label">RUNNING</span><strong>{system.resources.filter(r=>r.owner).length}</strong><small>Resources currently allocated</small></div><div className="stat-card"><span className="stat-label">WAITING</span><strong>{system.resources.reduce((n,r)=>n+r.queue.length,0)}</strong><small>Requests in FCFS queues</small></div><div className="stat-card"><span className="stat-label">AVAILABLE</span><strong>{counts.available+counts.seatsFree}</strong><small>Free resource instances</small></div><div className="stat-card"><span className="stat-label">MUTEX / SEMAPHORE</span><strong>Active</strong><small>Exclusive units and 50 seat capacity</small></div></div><section className="panel table-panel"><div className="section-heading compact"><div><h2>Current process table</h2><p>Allocated and waiting requests</p></div><span className="count-chip">{system.resources.filter(r=>r.owner||r.queue.length).length} resources active</span></div><div className="table-scroll"><table><thead><tr><th>PID / resource</th><th>Student</th><th>Resource</th><th>State</th><th>Time remaining</th></tr></thead><tbody>{system.resources.filter(r=>r.owner||r.queue.length).flatMap(r=>[...(r.owner?[{key:r.id,person:r.owner,state:'RUNNING',endsAt:r.endsAt,resource:r}]:[]),...r.queue.map((q,i)=>({key:`${r.id}-${i}`,person:q,state:'WAITING',resource:r}))]).map(p=><tr key={p.key}><td><strong>{p.key}</strong></td><td>{p.person.name}</td><td>{p.resource.label}</td><td><span className={`status ${p.state==='RUNNING'?'busy':'waiting-status'}`}>{p.state}</span></td><td>{p.state==='RUNNING'?fmt(timeLeft(p.endsAt,now)):'Queued'}</td></tr>)}</tbody></table></div></section></>}
      <footer className="page-footer"><span>© 2026 HostelSync · Smart resource management</span><span>Built with Operating Systems principles <b>•</b> Local demo mode</span></footer>
      </div>
    </main>
    {conflict && <div className="modal-backdrop" onClick={()=>setConflict(null)}><div className="modal-card" onClick={e=>e.stopPropagation()}><button className="modal-close" onClick={()=>setConflict(null)}>×</button><span className="modal-icon">⚠</span><span className="eyebrow">RESOURCE IN USE</span><h2>{conflict.label} is currently occupied</h2><p><strong>{conflict.owner.name}</strong> is already using this {LABELS[conflict.type].toLowerCase()}. What would you like to do?</p><div className="conflict-owner"><span className="profile-avatar">{conflict.owner.name.slice(0,1).toUpperCase()}</span><div><strong>{conflict.owner.name}</strong><small>Current booking · {conflict.owner.room ? `Room ${conflict.owner.room}` : 'Room not provided'}</small></div><span className="status busy">In use</span></div><button className="button button-primary full" onClick={()=>{setConflict(null);setTab('Resource center');if(conflict.type==='seat')document.querySelector('.seats-panel')?.scrollIntoView({behavior:'smooth'});else setFilter(conflict.type)}}>Choose another {conflict.type==='washer'?'machine':conflict.type==='seat'?'seat':conflict.type}</button><button className="button button-secondary full modal-secondary" onClick={()=>queueResource(conflict.id)}>Join waiting queue</button></div></div>}
    {expiry && <div className="modal-backdrop"><div className="modal-card expiry-card"><span className="modal-icon expired">⏱</span><span className="eyebrow">BOOKING TIME ENDED</span><h2>Your allocated time is up</h2><p>{expiry.owner.name}, your time for <strong>{expiry.label}</strong> has ended. Would you like to extend your booking or release the resource?</p><div className="expiry-summary"><span>{ICONS[expiry.type]}</span><div><strong>{expiry.label}</strong><small>{LABELS[expiry.type]} · Standard duration {durationLabel(expiry.type)}</small></div></div><button className="button button-primary full" onClick={()=>extendResource(expiry.resourceId)}>Extend by {durationLabel(expiry.type)}</button><button className="button button-danger full modal-secondary" onClick={()=>releaseResource(expiry.resourceId)}>Release resource</button><small className="muted">If you do not own this booking, ask the current user to release it.</small></div></div>}
  </div>
}
