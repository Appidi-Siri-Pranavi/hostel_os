export default function RAG({ os }) {
  const processes = os.procs
  const resources = os.resources

  const processNodes = processes.map((p, i) => ({
    ...p,
    x: 120,
    y: 100 + i * 120,
  }))

  const resourceNodes = resources.map((r, i) => ({
    ...r,
    x: 400,
    y: 80 + i * 100,
  }))

  return (
    <div className="card">
      <h3>Resource Allocation Graph</h3>

      <p>
        Circles represent processes and rectangles represent
        resources.
      </p>

      <svg
        width="100%"
        height="500"
        viewBox="0 0 600 500"
      >
        {processes.map((p) =>
          p.holds.map((rid) => {
            const r = resourceNodes.find((x) => x.id === rid)
            const node = processNodes.find((x) => x.pid === p.pid)

            if (!r || !node) return null

            return (
              <line
                key={`${p.pid}-${rid}`}
                x1={node.x + 30}
                y1={node.y}
                x2={r.x}
                y2={r.y}
                stroke="black"
                strokeWidth="2"
              />
            )
          })
        )}

        {processes.map((p) =>
          p.state === 'WAITING' ? (
            <line
              key={`wait-${p.pid}`}
              x1={processNodes.find((x) => x.pid === p.pid)?.x + 30}
              y1={processNodes.find((x) => x.pid === p.pid)?.y}
              x2={
                resourceNodes.find((x) => x.id === p.resource)?.x
              }
              y2={
                resourceNodes.find((x) => x.id === p.resource)?.y
              }
              stroke="red"
              strokeWidth="2"
              strokeDasharray="6"
            />
          ) : null
        )}

        {processNodes.map((p) => (
          <g key={p.pid}>
            <circle
              cx={p.x}
              cy={p.y}
              r="30"
              fill="white"
              stroke="black"
              strokeWidth="2"
            />

            <text
              x={p.x}
              y={p.y + 5}
              textAnchor="middle"
            >
              {p.pid}
            </text>
          </g>
        ))}

        {resourceNodes.map((r) => (
          <g key={r.id}>
            <rect
              x={r.x}
              y={r.y - 25}
              width="120"
              height="50"
              fill="white"
              stroke="black"
              strokeWidth="2"
            />

            <text
              x={r.x + 60}
              y={r.y + 5}
              textAnchor="middle"
            >
              {r.name}
            </text>
          </g>
        ))}
      </svg>
    </div>
  )
}