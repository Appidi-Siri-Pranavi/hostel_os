import { useState } from 'react'


export default function StudentHome({
  currentUser,
  onLogin,
  onOpenResources
}) {

  const [name, setName] =
    useState('')


  const [room, setRoom] =
    useState('')



  // ==========================================
  // LOGGED-IN HOME
  // ==========================================

  if (currentUser) {

    return (

      <div className="home-page">

        <div className="hero-card">

          <div className="hero-icon">
            🏠
          </div>

          <h1>
            Welcome to HostelSync
          </h1>

          <p>
            Your smart hostel resource
            management system.
          </p>


          <div className="student-profile">

            <div>
              <span>Student</span>

              <strong>
                {currentUser.name}
              </strong>
            </div>


            <div>
              <span>Room</span>

              <strong>
                {currentUser.room}
              </strong>
            </div>

          </div>


          <button
            className="primary-button large-button"
            onClick={onOpenResources}
          >
            Open Resource Center →
          </button>

        </div>



        <div className="info-grid">

          <div className="info-card">
            <span>🧺</span>

            <h3>
              40 Washing Machines
            </h3>

            <p>
              10 machines on each of
              4 floors.
            </p>
          </div>


          <div className="info-card">
            <span>⏱️</span>

            <h3>
              1 Hour Usage
            </h3>

            <p>
              Every resource automatically
              releases after one hour.
            </p>
          </div>


          <div className="info-card">
            <span>📋</span>

            <h3>
              FCFS Waiting
            </h3>

            <p>
              First person in the queue
              gets the resource next.
            </p>
          </div>

        </div>

      </div>

    )
  }



  // ==========================================
  // LOGIN PAGE
  // ==========================================

  const submit = (e) => {

    e.preventDefault()


    if (
      !name.trim() ||
      !room.trim()
    ) {

      return
    }


    onLogin({

      name:
        name.trim(),

      room:
        room.trim()

    })

  }



  return (

    <div className="login-page">

      <div className="login-card">

        <div className="login-icon">
          🏠
        </div>


        <h1>
          Welcome to HostelSync
        </h1>


        <p>
          Enter your details to access
          hostel facilities.
        </p>



        <form
          onSubmit={submit}
        >

          <label>
            Student Name
          </label>

          <input
            type="text"
            value={name}
            onChange={(e) =>
              setName(e.target.value)
            }
            placeholder="Enter your name"
          />



          <label>
            Room Number
          </label>

          <input
            type="text"
            value={room}
            onChange={(e) =>
              setRoom(e.target.value)
            }
            placeholder="Example: A-204"
          />



          <button
            type="submit"
            className="primary-button"
            disabled={
              !name.trim() ||
              !room.trim()
            }
          >
            Enter HostelSync →
          </button>

        </form>

      </div>

    </div>

  )
}