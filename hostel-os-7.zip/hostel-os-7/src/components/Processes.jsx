import { release } from '../os/scheduler'

export default function Processes({ os, act }) {
  return (
    <div className="card">
      <h3>Processes</h3>

      <div className="scroll">
        <table>
          <thead>
            <tr>
              <th>PID</th>
              <th>Student</th>
              <th>Requested</th>
              <th>Holds</th>
              <th>Priority</th>
              <th>State</th>
              <th>Action</th>
            </tr>
          </thead>

          <tbody>
            {os.procs.map((p) => (
              <tr key={p.pid}>
                <td>{p.pid}</td>
                <td>{p.student}</td>
                <td>{p.resource}</td>
                <td>{p.holds.join(', ') || '-'}</td>
                <td>{p.priority}</td>
                <td>{p.state}</td>

                <td>
                  {p.state === 'RUNNING' && (
                    <button
                      onClick={() =>
                        act((s) => release(s, p.pid))
                      }
                    >
                      Release
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}