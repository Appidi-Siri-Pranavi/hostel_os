export default function Scheduling({
  os
}) {

  const waitingResources =
    os.resources.filter(
      (r) =>
        r.queue.length > 0
    )


  return (

    <div className="queue-page">

      <div className="page-title">

        <h1>
          Waiting Queue
        </h1>

        <p>
          FCFS — First Come First Serve
        </p>

      </div>



      {waitingResources.length === 0 ? (

        <div className="empty-queue">

          <div>
            ✓
          </div>

          <h2>
            No one is waiting
          </h2>

          <p>
            All hostel resources are
            currently available.
          </p>

        </div>

      ) : (

        <>

          <div className="queue-summary">

            <strong>
              {os.procs.filter(
                (p) =>
                  p.state === 'WAITING'
              ).length}
            </strong>

            <span>
              students currently waiting
            </span>

          </div>



          <div className="queue-list">

            {waitingResources.map(
              (resource) => (

                <div
                  className="queue-card"
                  key={resource.id}
                >

                  <div className="queue-card-header">

                    <div>

                      <h2>
                        {resource.floor
                          ? `Floor ${resource.floor} • `
                          : ''}

                        {resource.name}
                      </h2>

                      <p>
                        {resource.floor &&
                          `Machine ${resource.machineNumber}`}
                      </p>

                    </div>


                    <span>
                      {resource.queue.length}
                      {' '}
                      waiting
                    </span>

                  </div>



                  <div className="queue-order">

                    {resource.queue.map(
                      (pid, index) => {

                        const process =
                          os.procs.find(
                            (p) =>
                              p.pid === pid
                          )


                        if (!process)
                          return null



                        return (

                          <div
                            className="queue-person"
                            key={pid}
                          >

                            <div className="queue-number">

                              {index + 1}

                            </div>


                            <div className="queue-person-info">

                              <strong>
                                {process.student}
                              </strong>

                              <span>
                                Room {process.room}
                              </span>

                              <small>
                                Process {process.pid}
                              </small>

                            </div>


                            <div className="queue-status">
                              WAITING
                            </div>

                          </div>

                        )

                      }
                    )}

                  </div>

                </div>

              )
            )}

          </div>

        </>

      )}

    </div>

  )
}