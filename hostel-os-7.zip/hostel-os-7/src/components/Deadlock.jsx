import { scenario, findCycle } from '../os/deadlock'
import RAG from './RAG'

export default function Deadlock({ os, act, cycle }) {
  const createScenario = () => {
    act((s) => scenario(s))
  }

  const detect = () => {
    act((s) => {
      s.cycle = findCycle(s.procs)
    })
  }

  const resolve = () => {
    act((s) => {
      if (s.cycle?.length) {
        s.procs = s.procs.filter(
          (p) => !s.cycle.includes(p.pid)
        )
      }

      s.cycle = null
    })
  }

  return (
    <>
      <div className="card">
        <h3>Deadlock Detection</h3>

        <p>
          Create a circular wait scenario and use DFS
          to detect the deadlock.
        </p>

        <div className="buttons">
          <button onClick={createScenario}>
            Create Deadlock Scenario
          </button>

          <button onClick={detect}>
            Detect Deadlock
          </button>

          <button onClick={resolve}>
            Resolve Deadlock
          </button>
        </div>

        {cycle && (
          <div className="alert">
            ⚠️ Deadlock detected!
            <br />
            Cycle: {cycle.join(' → ')}
          </div>
        )}
      </div>

      <RAG os={os} />
    </>
  )
}