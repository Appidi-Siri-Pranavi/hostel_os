import {
  useEffect,
  useState
} from 'react'

import {
  request,
  release
} from '../os/scheduler'



const formatTime = (milliseconds) => {

  const totalSeconds =
    Math.max(
      0,
      Math.ceil(
        milliseconds / 1000
      )
    )


  const hours =
    Math.floor(
      totalSeconds / 3600
    )


  const minutes =
    Math.floor(
      (totalSeconds % 3600) / 60
    )


  const seconds =
    totalSeconds % 60


  return (
    `${String(hours).padStart(2, '0')}:` +
    `${String(minutes).padStart(2, '0')}:` +
    `${String(seconds).padStart(2, '0')}`
  )
}



export default function Resources({
  os,
  act,
  currentUser,
  onSwitchStudent
}) {

  const [now, setNow] =
    useState(Date.now())


  const [modal, setModal] =
    useState(null)


  const [message, setMessage] =
    useState('')



  // Timer display
  useEffect(() => {

    const timer =
      setInterval(
        () => setNow(Date.now()),
        1000
      )


    return () =>
      clearInterval(timer)

  }, [])



  const showMessage = (text) => {

    setMessage(text)

    setTimeout(
      () => setMessage(''),
      4000
    )

  }



  // Find current student's process
  const getMyProcess = (resourceId) => {

    return os.procs.find(
      (p) =>
        p.student === currentUser.name &&
        p.resource === resourceId &&
        p.state !== 'COMPLETED'
    )

  }



  // Find running owner
  const getOwner = (resourceId) => {

    return os.procs.find(
      (p) =>
        p.resource === resourceId &&
        p.state === 'RUNNING'
    )

  }



  // ==========================================
  // REQUEST RESOURCE
  // ==========================================

  const requestResource = (resourceId) => {

    const resource =
      os.resources.find(
        (r) =>
          r.id === resourceId
      )


    if (!resource) return



    const existing =
      getMyProcess(resourceId)


    if (existing) {

      showMessage(
        `You already requested ${resource.name}.`
      )

      return
    }



    // Resource is full
    if (
      resource.sem <= 0
    ) {

      const owner =
        getOwner(resourceId)


      setModal({

        resourceId,

        resourceName:
          resource.name,

        owner

      })


      return
    }



    // Resource available
    act((s) => {

      request(
        s,
        currentUser.name,
        currentUser.room,
        resourceId
      )

    })


    showMessage(
      `${resource.name} requested successfully.`
    )

  }



  // ==========================================
  // JOIN WAITING QUEUE
  // ==========================================

  const joinQueue = () => {

    if (!modal) return


    act((s) => {

      request(
        s,
        currentUser.name,
        currentUser.room,
        modal.resourceId
      )

    })


    showMessage(
      `You joined the waiting queue for ${modal.resourceName}.`
    )


    setModal(null)

  }



  // ==========================================
  // RELEASE
  // ==========================================

  const releaseResource = (pid, resourceName) => {

    act((s) => {

      release(
        s,
        pid
      )

    })


    showMessage(
      `${resourceName} released.`
    )

  }



  // ==========================================
  // TIMER
  // ==========================================

  const getRemaining = (process) => {

    if (
      !process ||
      !process.startedAt
    ) {

      return 0
    }


    return Math.max(
      0,
      process.duration -
        (now - process.startedAt)
    )

  }



  // ==========================================
  // WASHING MACHINES
  // ==========================================

  const washingMachines =
    os.resources.filter(
      (r) =>
        r.category ===
        'Washing Machines'
    )



  const floors = [
    1,
    2,
    3,
    4
  ]



  return (

    <div className="resource-center">

      <div className="resource-header">

        <div>

          <h1>
            Hostel Resource Center
          </h1>

          <p>
            Welcome, {currentUser.name}
            {' '}• Room {currentUser.room}
          </p>

        </div>


        <button
          className="switch-button"
          onClick={onSwitchStudent}
        >
          Switch Student
        </button>

      </div>



      {message && (

        <div className="success-message">
          ✓ {message}
        </div>

      )}



      {/* =====================================
          WASHING MACHINES
      ===================================== */}

      <div className="resource-section">

        <div className="section-heading">

          <div>

            <span className="section-icon">
              🧺
            </span>

            <div>

              <h2>
                Washing Machines
              </h2>

              <p>
                40 machines • 10 on each floor
              </p>

            </div>

          </div>

        </div>



        {floors.map((floor) => {

          const machines =
            washingMachines.filter(
              (m) =>
                m.floor === floor
            )


          return (

            <div
              className="floor-section"
              key={floor}
            >

              <div className="floor-title">

                <h3>
                  Floor {floor}
                </h3>

                <span>
                  10 Washing Machines
                </span>

              </div>



              <div className="machine-grid">

                {machines.map(
                  (machine) => {

                    const running =
                      getOwner(
                        machine.id
                      )


                    const mine =
                      getMyProcess(
                        machine.id
                      )


                    const waiting =
                      machine.queue.length


                    const available =
                      machine.sem > 0



                    return (

                      <div
                        key={machine.id}
                        className={
                          `machine-card ${
                            available
                              ? 'available'
                              : 'busy'
                          }`
                        }
                      >

                        <div className="machine-number">
                          🧺
                        </div>


                        <strong>
                          WM {machine.machineNumber}
                        </strong>



                        {available && (

                          <button
                            className="machine-use"
                            onClick={() =>
                              requestResource(
                                machine.id
                              )
                            }
                          >
                            Use
                          </button>

                        )}



                        {!available &&
                          running && (

                          <div className="machine-owner">

                            <span>
                              🔴 In Use
                            </span>

                            <b>
                              {running.student}
                            </b>

                            <small>
                              Room {running.room}
                            </small>


                            {mine && (

                              <>

                                <div className="timer-box">

                                  <small>
                                    Time remaining
                                  </small>

                                  <strong>
                                    {formatTime(
                                      getRemaining(
                                        mine
                                      )
                                    )}
                                  </strong>

                                </div>


                                <button
                                  className="release-small"
                                  onClick={() =>
                                    releaseResource(
                                      mine.pid,
                                      machine.name
                                    )
                                  }
                                >
                                  Release
                                </button>

                              </>

                            )}

                          </div>

                        )}



                        {waiting > 0 && (

                          <div className="queue-count">

                            🕐 {waiting}
                            {' '}
                            waiting

                          </div>

                        )}

                      </div>

                    )

                  }
                )}

              </div>

            </div>

          )

        })}

      </div>



      {/* =====================================
          OTHER RESOURCES
      ===================================== */}

      <div className="other-resource-grid">

        {[
          {
            id: 'DR',
            icon: '👕',
            title: 'Dryers',
            description: '25 dryers available'
          },

          {
            id: 'CR',
            icon: '🛋️',
            title: 'Common Rooms',
            description: '10 common spaces'
          },

          {
            id: 'IR',
            icon: '🔥',
            title: 'Iron Boxes',
            description: '25 iron boxes'
          }

        ].map(
          (item) => {

            const resource =
              os.resources.find(
                (r) =>
                  r.id === item.id
              )


            if (!resource)
              return null



            const activeUsers =
              os.procs.filter(
                (p) =>
                  p.resource === item.id &&
                  p.state === 'RUNNING'
              )


            const mine =
              getMyProcess(
                item.id
              )



            return (

              <div
                className="other-resource-card"
                key={item.id}
              >

                <div className="other-icon">
                  {item.icon}
                </div>


                <h2>
                  {item.title}
                </h2>


                <p>
                  {resource.sem} of {resource.total}
                  {' '}available
                </p>



                <div className="availability-bar">

                  <div
                    style={{
                      width:
                        `${(
                          resource.sem /
                          resource.total
                        ) * 100}%`
                    }}
                  />

                </div>



                <h4>
                  Currently Using
                </h4>


                {activeUsers.length === 0 ? (

                  <p className="empty-text">
                    No one is using this resource.
                  </p>

                ) : (

                  <div className="users-list">

                    {activeUsers
                      .slice(0, 5)
                      .map(
                        (p) => (

                          <div
                            className="user-row"
                            key={p.pid}
                          >

                            <div>

                              <b>
                                {p.student}
                              </b>

                              <small>
                                Room {p.room}
                              </small>

                            </div>


                            <span>
                              Using
                            </span>

                          </div>

                        )
                      )}

                  </div>

                )}



                {mine ? (

                  <div className="my-resource">

                    <div className="timer-box">

                      <small>
                        Your time remaining
                      </small>

                      <strong>
                        {formatTime(
                          getRemaining(
                            mine
                          )
                        )}
                      </strong>

                    </div>


                    <button
                      className="release-button"
                      onClick={() =>
                        releaseResource(
                          mine.pid,
                          item.title
                        )
                      }
                    >
                      Release {item.title}
                    </button>

                  </div>

                ) : (

                  <button
                    className="primary-button resource-use-button"
                    onClick={() =>
                      requestResource(
                        item.id
                      )
                    }
                    disabled={
                      resource.sem <= 0
                    }
                  >
                    {resource.sem > 0
                      ? `Use ${item.title}`
                      : 'Currently Full'}
                  </button>

                )}

              </div>

            )

          }
        )}

      </div>



      {/* =====================================
          WAITING INFO
      ===================================== */}

      <div className="waiting-info">

        <h2>
          📋 How waiting works
        </h2>

        <p>
          If your selected washing machine is
          occupied, HostelSync shows the current
          user and gives you two choices:
        </p>


        <div className="choice-explanation">

          <div>
            <b>
              🕐 Wait for this machine
            </b>

            <span>
              Join the FCFS queue.
            </span>
          </div>


          <div>
            <b>
              🧺 Choose another machine
            </b>

            <span>
              Return to the floor list and
              select another available machine.
            </span>
          </div>

        </div>

      </div>



      {/* =====================================
          BUSY RESOURCE MODAL
      ===================================== */}

      {modal && (

        <div className="modal-overlay">

          <div className="modal-card">

            <div className="modal-icon">
              ⏳
            </div>


            <h2>
              Resource Currently Busy
            </h2>


            <p>
              <b>
                {modal.resourceName}
              </b>
              {' '}is currently being used by:
            </p>


            {modal.owner && (

              <div className="owner-box">

                <strong>
                  {modal.owner.student}
                </strong>

                <span>
                  Room {modal.owner.room}
                </span>

                {modal.owner.startedAt && (

                  <small>
                    Time remaining:
                    {' '}
                    {formatTime(
                      getRemaining(
                        modal.owner
                      )
                    )}
                  </small>

                )}

              </div>

            )}



            <p className="modal-question">
              What would you like to do?
            </p>



            <div className="modal-buttons">

              <button
                className="wait-button"
                onClick={joinQueue}
              >
                🕐 Wait for this machine
              </button>


              <button
                className="choose-button"
                onClick={() =>
                  setModal(null)
                }
              >
                🧺 Choose another machine
              </button>

            </div>

          </div>

        </div>

      )}

    </div>

  )
}