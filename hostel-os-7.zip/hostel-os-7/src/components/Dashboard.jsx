const concepts = [
  ['Process', 'Every resource request becomes a process'],
  ['Process States', 'READY, RUNNING, WAITING, COMPLETED'],
  ['Resource Allocation', 'Processes acquire and release resources'],
  ['Semaphore', 'Counts free instances of each resource'],
  ['FCFS Scheduling', 'Waiting queue served in arrival order'],
  ['Deadlock + RAG', 'DFS cycle detection on a wait-for graph'],
]

export default function Dashboard({ os, cycle }) {

  const active = os.procs.filter(
    (p) => p.state !== 'COMPLETED'
  ).length

  const waiting = os.procs.filter(
    (p) => p.state === 'WAITING'
  ).length

  const free = os.resources.reduce(
    (n, r) => n + r.sem,
    0
  )

  const stats = [
    ['Active Processes', active, 'blue'],
    ['Waiting Processes', waiting, 'yellow'],
    ['Available Resources', free, 'green'],
    ['Deadlocks', cycle ? 1 : 0, 'red'],
  ]

  return (
    <>
      <div className="grid4">

        {stats.map(([title, value, color]) => (

          <div
            className={`card stat ${color}`}
            key={title}
          >
            <small>{title}</small>
            <h2>{value}</h2>
          </div>

        ))}

      </div>


      <div className="card">

        <h3>OS Concepts Demonstrated</h3>

        <div className="scroll">

          <table>

            <thead>
              <tr>
                <th>OS Concept</th>
                <th>Implementation</th>
              </tr>
            </thead>

            <tbody>

              {concepts.map(([a, b]) => (

                <tr key={a}>
                  <td>{a}</td>
                  <td>{b}</td>
                </tr>

              ))}

            </tbody>

          </table>

        </div>

      </div>
    </>
  )
}