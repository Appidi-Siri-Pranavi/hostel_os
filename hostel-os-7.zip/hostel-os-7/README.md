# HostelSync — Hostel Resource Management OS

A React + Vite prototype for managing hostel resources and demonstrating Operating Systems concepts.

## Run locally
1. Install Node.js (LTS) if it is not already installed.
2. Open this folder in VS Code.
3. Open Terminal and run `npm install`.
4. Run `npm run dev`.
5. Open the localhost URL printed by Vite.

## Included
- 3 floors, 4 washing machines per floor, 2 dryers per floor, 2 iron boxes per floor
- 50 common-room seats
- Usage timers: washer 60 minutes, dryer/iron 30 minutes, seat 2 hours
- Booking, release, extension prompt, occupied-resource conflict prompt, FCFS queue
- Dashboard, booking view, process/resource status and deadlock teaching simulation
- Browser storage persistence and optional browser notifications while the site is open

## Important deployment note
This package is a frontend demonstration. `localStorage` synchronizes data only within the same browser profile; it is **not** a shared multi-device database, and in-app timers/notifications require the site to be open. For all hostel students to use one shared live system, deploy the frontend and connect it to a backend/database (for example, a Node/Express API with PostgreSQL or Firebase) and implement server-side timer jobs/push notifications. Do not treat this demo as a production booking system without that backend.
