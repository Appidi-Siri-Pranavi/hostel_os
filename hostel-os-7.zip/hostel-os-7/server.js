import http from 'node:http';
import { readFile, writeFile } from 'node:fs/promises';
const PORT = 3001; const FILE = new URL('./hostelsync-shared-state.json', import.meta.url);
const server = http.createServer(async (req,res)=>{
  res.setHeader('Access-Control-Allow-Origin','*'); res.setHeader('Access-Control-Allow-Headers','Content-Type'); res.setHeader('Access-Control-Allow-Methods','GET,POST,OPTIONS');
  if(req.method==='OPTIONS'){res.writeHead(204);return res.end()}
  if(req.url==='/api/state' && req.method==='GET'){try{res.writeHead(200,{'Content-Type':'application/json'});res.end(await readFile(FILE,'utf8'))}catch{res.writeHead(404);res.end('{}')}return}
  if(req.url==='/api/state' && req.method==='POST'){let body='';req.on('data',c=>body+=c);req.on('end',async()=>{try{const data=JSON.parse(body);if(data?.resources?.length===74)await writeFile(FILE,JSON.stringify(data));res.writeHead(200,{'Content-Type':'application/json'});res.end('{"ok":true}')}catch{res.writeHead(400);res.end('{"ok":false}')}});return}
  res.writeHead(404);res.end('Not found');
});server.listen(PORT,'0.0.0.0',()=>console.log(`HostelSync shared booking server: http://0.0.0.0:${PORT}`));
